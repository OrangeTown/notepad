(function ($) {
    'use strict';
    var conf = window.conf = window.conf || {};
    $.extend(conf, {
        splashing: true,
        currentPack: '',
        inRamPack: {},

    });

}(jQuery));